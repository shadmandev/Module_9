<?php $__env->startSection('title','Create Project'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card mt-4">
        <div class="card-header d-flex align-items-center justify-content-between">
            <div>Create Project</div>
            <div>
                <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-primary btn-lg px-4 me-md-2 mr-3">Back to List</a>
            </div>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('projects.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="name" class="form-label">Email address</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Project Name">
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Project Description</label>
                    <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                </div>
                <div class="mb-3">
                    <input type="submit" value="Create" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ostad\Module_9\resources\views/createProject.blade.php ENDPATH**/ ?>