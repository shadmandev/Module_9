@extends('layouts.app')

@section('title','Blogs')

@push('css')

@endpush

@section('content')
@endsection

@push('js')
@endpush
