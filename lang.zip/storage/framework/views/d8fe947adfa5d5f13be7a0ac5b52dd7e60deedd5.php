<?php $__env->startSection('title','Projects'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section class="container pt-4">
    <div class="d-flex align-items-center justify-content-between">
        <h2 class="h2 text-center pb-4">Projects</h2>
        <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary btn-lg px-4 me-md-2 mr-3">Create New</a>
    </div>
    <div class="row">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card mb-3">
                    <div class="card-header">
                        <img src="https://devshadman.com/wp-content/uploads/2023/06/support.svg" >
                    </div>

                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($project->name); ?></h5>
                        <p class="card-text">
                            <?php echo e($project->description); ?>

                        </p>
                    </div>
                    <div class="card-footer">
                        <div>
                            
                            <span>
                                <button type="button" class="btn btn-danger btn-sm text-white" onclick="deleteData(<?php echo e($project->id); ?>)">
                                    <i class="fa-regular fa-trash-can"></i>
                                </button>
                                <form id="delete-form-<?php echo e($project->id); ?>"
                                    action="<?php echo e(route('projects.destroy',$project->id)); ?>" method="POST"
                                    style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                </form>
                                
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ostad\Module_9\resources\views/project.blade.php ENDPATH**/ ?>